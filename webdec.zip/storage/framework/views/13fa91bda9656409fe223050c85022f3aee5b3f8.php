<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-users icon"></i>
                    <span style="font-size: 1.2rem"><?php echo e(__('Usuários Cadastrados')); ?></span>
                </div>

                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row">
                            <div class="col-md-8">
                                <p><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></p>
                            </div>
                            <div class="col-auto">
                                <a href="<?php echo e(route('users.edit', ['id' => $user->id])); ?>">
                                    <span class="d-inline-block" tabindex="0" data-placement="top" data-toggle="tooltip" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </span>
                                </a>
                            </div>
                            <?php if($user->id != Auth::user()->id): ?>
                                <div class="col-auto">
                                    <a href="<?php echo e(route('users.destroy', ['id' => $user->id])); ?>">
                                        <span class="d-inline-block" tabindex="0" data-placement="top" data-toggle="tooltip" title="Apagar">
                                            <i class="fas fa-trash-alt"></i>
                                        </span> 
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Nenhum usuário cadastrado!</p>
                    <?php endif; ?>
                    <div class="card-footer bg-transparent">
                        <nav aria-label="Users pagination">
                            <div class="pagination pagination-sm justify-content-end">
                                <?php echo e($users->links()); ?>

                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\webdec\resources\views/home.blade.php ENDPATH**/ ?>