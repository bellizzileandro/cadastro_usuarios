<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Editar dados do usuário')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(route('users.update', ['user' => $user->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="lastname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sobrenome')); ?></label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="lastname" value="<?php echo e(old('lastname', $user->lastname)); ?>" required autocomplete="lastname">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="birthdate" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Data de nascimento')); ?></label>
                            <div class="col-md-6">
                                <input id="birthdate" type="date" class="form-control <?php if ($errors->has('birthdate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birthdate'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="birthdate" value="<?php echo e(old('birthdate', $user->birthdate)); ?>" required autocomplete="birthdate" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="gender" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sexo')); ?></label>
                            <div class="col-md-6">
                                <select name="gender" id="gender" class="custom-select form-control <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value=<?php echo e(old('gender', $user->gender)); ?>>
                                    <?php if($user->gender == 'F'): ?>
                                        <option value="F" selected><?php echo e(__('Feminino')); ?></option>
                                        <option value="M"><?php echo e(__('Masculino')); ?></option>
                                    <?php elseif($user->gender == 'M'): ?>
                                        <option value="F"><?php echo e(__('Feminino')); ?></option>
                                        <option value="M" selected><?php echo e(__('Masculino')); ?></option>
                                    <?php else: ?>
                                        <option value="F"><?php echo e(__('Feminino')); ?></option>
                                        <option value="M"><?php echo e(__('Masculino')); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-auto offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Salvar')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\webdec\resources\views/update.blade.php ENDPATH**/ ?>