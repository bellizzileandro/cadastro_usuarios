<?php $__env->startSection('content'); ?>
    <section class="py-4 greeting">
        <p>Olá, <?php echo e($greeting); ?>!</p>
        <p>Bem vindo ao teste prático para a WebDec</p>
        <p>Este teste foi criado utilizando Laravel em sua versão 5.8 e MySql.</p>
    </section>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\webdec\resources\views/welcome.blade.php ENDPATH**/ ?>